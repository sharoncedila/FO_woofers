import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:woofers/pages/login_page.dart';
import 'package:woofers/services/account_service.dart';

class ProfilePageTemplate extends StatelessWidget {
  final int initialIndex;
  ProfilePageTemplate({super.key, this.initialIndex = 0});

  @override
  final _logoutService = AccountService();
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: initialIndex,
      length: 3,
      child: Scaffold(
        // appBar: AppBar(
        //   automaticallyImplyLeading: false,
        //   bottom: const TabBar(
        //     tabs: [
        //       Tab(
        //         icon: Icon(Icons.person),
        //         text: "Me",
        //       ),
        //       Tab(
        //         icon: Icon(Icons.pets),
        //         text: "Doggo",
        //       ),
        //       Tab(
        //         icon: Icon(Icons.favorite),
        //         text: "Favo",
        //       ),
        //     ],
        //   ),
        // ),
        // body: const TabBarView(
        //   children: [
        //     UserProfilePage(),
        //     DogListPage(),
        //     FavoritFeedsPage(),
        //   ],
        // ),
        appBar: AppBar(
          toolbarHeight: 75,
          elevation: 0,
          backgroundColor: HexColor("#a0dcdc"),
          title: Text(
            "WOOFERS",
            style: GoogleFonts.lora(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: const Color.fromRGBO(40, 36, 36, 10000),
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.resolveWith<Color?>(
                  (Set<MaterialState> states) {
                    if (states.contains(MaterialState.pressed)) {
                      return Theme.of(context)
                          .colorScheme
                          .primary
                          .withOpacity(0.5);
                    }
                    return null;
                  },
                ),
              ),
              child: const Text('Logout'),
              onPressed: () async {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('Confirmation'),
                      content: const Text(
                          'Are you sure want to log out your account?'),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop(false);
                          },
                          child: const Text('No'),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop(true);
                          },
                          child: const Text('Yes'),
                        ),
                      ],
                    );
                  },
                ).then((value) {
                  // yess
                  if (value != null && value) {
                    _logoutService.logout();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const LoginPage()),
                    );
                  }
                  // no
                  // else {
                  //   // If 'No' is pressed or the dialog is dismissed
                  //   // print('User canceled');
                  //   // Perform the desired action or do nothing
                  // }
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
