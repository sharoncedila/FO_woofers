import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:woofers/components/bottom_menu.dart';
import 'package:woofers/model/account_model.dart';
import 'package:woofers/pages/register_page.dart';
import 'package:woofers/pages/admin_login_page.dart';
import 'package:woofers/services/account_service.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        //resizeToAvoidBottomInset: false,
        //backgroundColor: Color.fromRGBO(160, 220, 220, 1.0),
        backgroundColor: Colors.grey[300],
        body: // SafeArea(
            // child:
            Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                // logo
                Image.asset(
                  'assets/woofers_icon/woofers_logo.png',
                  width: 150,
                  height: 150,
                ),

                const SizedBox(height: 10),
                // WOOFERS
                Text(
                  'WOOFERS',
                  style: GoogleFonts.lora(
                    fontSize: 18,
                    //color: Colors.white,
                    color: const Color.fromRGBO(40, 36, 36, 10000),
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const LoginForm(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  const LoginForm({super.key});

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a GlobalKey<FormState>,
  // not a GlobalKey<LoginFormState>.
  final _formKey = GlobalKey<FormState>();
  bool passwordVisible = true;
  final _loginService = AccountService();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Form(
      key: _formKey,
      //child: Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // email form field
            const SizedBox(height: 50),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: TextFormField(
                //controller email
                controller: _emailController,
                decoration: InputDecoration(
                    enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    fillColor: Colors.grey.shade200,
                    filled: true,
                    hintText: 'Email',
                    hintStyle: TextStyle(color: Colors.grey[500])),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please fill email field';
                  }
                  bool isvalid = EmailValidator.validate(value);
                  if (isvalid == false) {
                    return 'Please check inserted email';
                  }
                  return null;
                },
              ),
            ),

            // password form field
            const SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: TextFormField(
                //controller password
                controller: _passwordController,
                obscureText: passwordVisible,
                decoration: InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                  ),
                  fillColor: Colors.grey.shade200,
                  filled: true,
                  hintText: 'Password',
                  hintStyle: TextStyle(color: Colors.grey[500]),
                  suffixIcon: IconButton(
                    icon: Icon(passwordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                    onPressed: () {
                      setState(
                        () {
                          passwordVisible = !passwordVisible;
                        },
                      );
                    },
                  ),
                  alignLabelWithHint: false,
                ),
                keyboardType: TextInputType.visiblePassword,
                textInputAction: TextInputAction.done,
                validator: (password) {
                  if (password == null || password.isEmpty) {
                    return 'Please fill password field';
                  }
                  if (password.length < 8) {
                    return 'Password must contain more than equal to 8 characters';
                  }
                  if (!password.contains(RegExp(r'[A-Z]'))) {
                    return 'Password must contain at least 1 uppercase letter';
                  }
                  // Contains at least one lowercase letter
                  if (!password.contains(RegExp(r'[a-z]'))) {
                    return 'Password must contain at least 1 lowercase letter';
                  }
                  // Contains at least one digit
                  if (!password.contains(RegExp(r'[0-9]'))) {
                    return 'Password must contain at least 1 digit';
                  }
                  // Contains at least one special character
                  if (!password.contains(RegExp(r'[!@#%^&*(),.?":{}|<>]'))) {
                    return 'Password must contain at least 1 special character';
                  }
                  return null;
                },
              ),
            ),

            const SizedBox(height: 50),
            SizedBox(
              width: 200,
              height: 45,
              child: ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.resolveWith<Color?>(
                    (Set<MaterialState> states) {
                      if (states.contains(MaterialState.pressed)) {
                        return Theme.of(context)
                            .colorScheme
                            .primary
                            .withOpacity(0.5);
                      }
                      return null; // Use the component's default.
                    },
                  ),
                ),
                child: Text(
                  'LOGIN',
                  style: TextStyle(
                      color: Colors.grey[600],
                      fontWeight: FontWeight.bold,
                      fontSize: 18),
                ),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    final RequestLoginModel loginReq = RequestLoginModel(
                        email: _emailController.text,
                        password: _passwordController.text);

                    _loginService
                        .login(loginReq)
                        .then((value) => Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                                builder: (_) => const BottomMenuBar())))
                        .onError<Exception>((error, stackTrace) {
                      // showDialog(
                      //   context: context,
                      //   builder: (context) {
                      //     //return Text(error.toString());
                      //     return SimpleDialog(
                      //       children: [Text(error.toString())],
                      //     );
                      //   },
                      // );
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: const Text("Error"),
                            content: Text(error.toString()),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context); // Close the dialog
                                },
                                child: const Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    });
                  }
                },
              ),
            ),

            // register now
            const SizedBox(height: 2),
            // register now

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Don\'t have any account? ',
                  style: TextStyle(
                    //color: Colors.white,
                    color: Colors.grey[700],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(0.7),
                  child: TextButton(
                    child: const Text(
                      'Register now',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const RegisterPage()),
                      );
                    },
                  ),
                ),
              ],
            ),
            Text(
              '\n\n\n\n\n\n',
              style: TextStyle(
                //color: Colors.white,
                color: Colors.grey[700],
                fontWeight: FontWeight.bold,
              ),
            ),
            TextButton(
              child: const Text(
                'Login as admin',
                style: TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const AdminLoginPage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
